#Enemy class
import random

class enemy:
    hp = 150
    attack = 8
    df = 10
        
