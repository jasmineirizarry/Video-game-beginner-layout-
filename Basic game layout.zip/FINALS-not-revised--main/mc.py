import random

class main_character:
    hp = 100
    atk = random.randint(50,150)
    df = 10

    inventory =[]
